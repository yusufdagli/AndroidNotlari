package com.ysfyazilim.baseadapterkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.ysfyazilim.baseadapterkullanimi.Adapter.AdapterMeyve;
import com.ysfyazilim.baseadapterkullanimi.Model.Meyve;
import com.ysfyazilim.baseadapterkullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Meyve> meyveler = new ArrayList<>();
    AdapterMeyve adapterMeyve;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView =findViewById(R.id.listView);
        meyveler.add(new Meyve("Elma",R.drawable.elma));
        meyveler.add(new Meyve("Elma",R.drawable.armut));
        meyveler.add(new Meyve("Elma",R.drawable.cilek));
        adapterMeyve = new AdapterMeyve(meyveler,getApplicationContext());
    }
}
