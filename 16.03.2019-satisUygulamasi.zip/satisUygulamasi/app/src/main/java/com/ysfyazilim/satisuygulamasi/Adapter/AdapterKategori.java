package com.ysfyazilim.satisuygulamasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ysfyazilim.satisuygulamasi.Model.Kategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class AdapterKategori extends BaseAdapter {
    private ArrayList<Kategori> kategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterKategori() {
    }

    public AdapterKategori(ArrayList<Kategori> kategoriler, Context context) {
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Kategori getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = layoutInflater.inflate(R.layout.kategori_customrow,null);
        ImageView iv = view.findViewById(R.id.ivKategoriResim);
        TextView tvBaslik = view.findViewById(R.id.tvKategoriBaslik);
        tvBaslik.setText(kategoriler.get(position).getAd());
        Glide
                .with(context)
                .load(kategoriler.get(position).getResim())
                .into(iv);
        return view;
    }
}
