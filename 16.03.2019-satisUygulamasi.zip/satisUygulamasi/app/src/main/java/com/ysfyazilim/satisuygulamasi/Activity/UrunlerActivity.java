package com.ysfyazilim.satisuygulamasi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ysfyazilim.satisuygulamasi.R;

public class UrunlerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunler);
    }
}
