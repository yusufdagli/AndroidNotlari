package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.ysfyazilim.satisuygulamasi.Adapter.AdapterAltKategori;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.Model.Kategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {
    ListView listViewAltKategoriler;
    AdapterAltKategori adapterAltKategori;
    ArrayList<AltKategori> altKategoriler = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);
        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());
        listViewAltKategoriler = findViewById(R.id.listViewAltKategoriler);
        if (kategori.getId()==1)
        {
            altKategoriler.add(new AltKategori(1,1,"Laptop","https://productimages.hepsiburada.net/s/23/552/10057885941810.jpg?v1","Laptoplar"));
            altKategoriler.add(new AltKategori(2,1,"Masaüstü","https://productimages.hepsiburada.net/s/25/552/10105973375026.jpg?v1","Masaüstü Bilgisayarlar"));
        }
        else if (kategori.getId()==2)
        {
            altKategoriler.add(new AltKategori(3,2,"Pantalon","https://media.decathlon.re/7535749/pantalon-chasse-steppe-300-vert.jpg","Pantalon - Giyim"));
            altKategoriler.add(new AltKategori(4,2,"Gömlek","https://kv9wxco8.rocketcdn.com/Content/global/images/products/TK030E8S03/erkek-tribun-waffle-gomlek.jpg","Gömlek - Giyim"));
        }

        adapterAltKategori = new AdapterAltKategori(altKategoriler,getApplicationContext());
        listViewAltKategoriler.setAdapter(adapterAltKategori);
        listViewAltKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                startActivity(intent);
            }
        });






    }
}
