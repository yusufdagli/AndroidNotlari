package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.ysfyazilim.satisuygulamasi.Adapter.AdapterAltKategori;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.Model.Kategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {
    ListView listViewAltKategoriler;
    AdapterAltKategori adapterAltKategori;
    ArrayList<AltKategori> altKategoriler = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);
        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());


        //toolbar geri butonu ekleme
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listViewAltKategoriler = findViewById(R.id.listViewAltKategoriler);
        if (kategori.getId()==1)
        {
            altKategoriler.add(new AltKategori(1,1,"Laptop","https://productimages.hepsiburada.net/s/23/552/10057885941810.jpg?v1","Laptoplar"));
            altKategoriler.add(new AltKategori(2,1,"Masaüstü","https://productimages.hepsiburada.net/s/25/552/10105973375026.jpg?v1","Masaüstü Bilgisayarlar"));
        }
        else if (kategori.getId()==2)
        {
            altKategoriler.add(new AltKategori(3,2,"Pantalon","https://media.decathlon.re/7535749/pantalon-chasse-steppe-300-vert.jpg","Pantalonlar"));
            altKategoriler.add(new AltKategori(4,2,"Gömlek","https://kv9wxco8.rocketcdn.com/Content/global/images/products/TK030E8S03/erkek-tribun-waffle-gomlek.jpg","Gömlekler"));
        }
        else if (kategori.getId()==3)
        {
            altKategoriler.add(new AltKategori(5,3,"Çamaşır Makinesi","https://ikincielbeyazesya.istanbul/wp-content/uploads/2017/08/IMG_2869.jpg","Çamaşır Makineleri"));
            altKategoriler.add(new AltKategori(6,3,"Buzdolabı","https://productimages.hepsiburada.net/s/21/552/9906046500914.jpg?v1","Buzdolapları"));
        }
        else if (kategori.getId()==4)
        {
            altKategoriler.add(new AltKategori(7,4,"Masa","https://cdnr.koctas.com.tr/resize/c450a91039db4701/900/900/productimages/1000231665/1000231665_1_MC/8808545255474_1531303757756.jpg","Masalar"));
            altKategoriler.add(new AltKategori(8,4,"Koltuk","https://cdn.vivense.com/images/stories/virtuemart/product/UV3/UV3-550-2.jpg","Koltuk Takımları"));
        }

        adapterAltKategori = new AdapterAltKategori(altKategoriler,getApplicationContext());
        listViewAltKategoriler.setAdapter(adapterAltKategori);
        listViewAltKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                intent.putExtra("altkategori",altKategoriler.get(position));
                startActivity(intent);
            }
        });






    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
