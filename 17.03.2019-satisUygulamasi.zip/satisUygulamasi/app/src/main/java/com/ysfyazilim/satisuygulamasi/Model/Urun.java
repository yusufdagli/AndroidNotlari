package com.ysfyazilim.satisuygulamasi.Model;

import java.io.Serializable;

public class Urun implements Serializable {
    private int id;
    private int altKategoriId;
    private String baslik;
    private double fiyat;
    private String resim;
    private String aciklama;

    public Urun() {
    }

    public Urun(int id, int altKategoriId, String baslik, double fiyat, String resim, String aciklama) {
        this.id = id;
        this.altKategoriId = altKategoriId;
        this.baslik = baslik;
        this.fiyat = fiyat;
        this.resim = resim;
        this.aciklama = aciklama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAltKategoriId() {
        return altKategoriId;
    }

    public void setAltKategoriId(int altKategoriId) {
        this.altKategoriId = altKategoriId;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }
}
