package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import com.ysfyazilim.satisuygulamasi.Adapter.AdapterUrun;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.Model.Urun;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;
import java.util.List;

public class UrunlerActivity extends AppCompatActivity {
    GridView gridViewUrunler;
    AdapterUrun adapterUrun;
    ArrayList<Urun> urunler = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunler);
        AltKategori altKategori =(AltKategori)getIntent().getSerializableExtra("altkategori");
        this.setTitle(altKategori.getKategoriAdi() + " Ürünleri");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        gridViewUrunler = findViewById(R.id.gridViewUrunler);
        if(altKategori.getId()==1)
        {
            urunler.add(new Urun(1,1,"Hp i3 Laptop",2495,"https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(2,1,"Hp i5 Laptop",3570,"https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(3,1,"Hp i7 Laptop",2400,"https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(4,1,"Hp Dual Core Laptop",1500,"https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(5,1,"Hp Atom Laptop",800,"https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1","Hp i5 4gb ram 2 gb Ekran Kartı"));


        }
        else if(altKategori.getId()==2)
        {
            urunler.add(new Urun(1,2,"Hp i3 Masaüstü PC",2700,"https://st1.myideasoft.com/idea/ay/59/myassets/products/470/ahr0cdovl2luaxnob3auy29tl2ltzy9nywxszxj5lzqyodk1ndm4xzmxnzm0otmxmjguanbn.jpg?revision=1546957953","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(2,2,"Hp i5 Masaüstü PC",2550,"https://st1.myideasoft.com/idea/ay/59/myassets/products/470/ahr0cdovl2luaxnob3auy29tl2ltzy9nywxszxj5lzqyodk1ndm4xzmxnzm0otmxmjguanbn.jpg?revision=1546957953","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(3,2,"Hp i7 Masaüstü PC",3000,"https://st1.myideasoft.com/idea/ay/59/myassets/products/470/ahr0cdovl2luaxnob3auy29tl2ltzy9nywxszxj5lzqyodk1ndm4xzmxnzm0otmxmjguanbn.jpg?revision=1546957953","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(4,2,"Hp Dual Core Masaüstü PC",5000,"https://st1.myideasoft.com/idea/ay/59/myassets/products/470/ahr0cdovl2luaxnob3auy29tl2ltzy9nywxszxj5lzqyodk1ndm4xzmxnzm0otmxmjguanbn.jpg?revision=1546957953","Hp i5 4gb ram 2 gb Ekran Kartı"));
            urunler.add(new Urun(5,2,"Hp Atom Masaüstü PC",800,"https://st1.myideasoft.com/idea/ay/59/myassets/products/470/ahr0cdovl2luaxnob3auy29tl2ltzy9nywxszxj5lzqyodk1ndm4xzmxnzm0otmxmjguanbn.jpg?revision=1546957953","Hp i5 4gb ram 2 gb Ekran Kartı"));


        }
        adapterUrun = new AdapterUrun(urunler,getApplicationContext());
        gridViewUrunler.setAdapter(adapterUrun);
        gridViewUrunler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent =new Intent(getApplicationContext(),UrunDetayActivity.class);
                intent.putExtra("urun",urunler.get(position));
                startActivity(intent);
            }
        });





    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()== android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
