package com.ysfyazilim.satisuygulamasi.Adapter;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class AdapterAltKategori extends BaseAdapter{
    private ArrayList<AltKategori> altkategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterAltKategori() {
    }

    public AdapterAltKategori(ArrayList<AltKategori> altkategoriler, Context context) {
        this.altkategoriler = altkategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return altkategoriler.size();
    }

    @Override
    public AltKategori getItem(int position) {
        return altkategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.altkategori_customrow,null);
        ImageView ivAltKategoriResim = v.findViewById(R.id.ivAltKategoriResim);
        TextView  tvAltKategoriAdi = v.findViewById(R.id.tvAltKategoriAdi);
        TextView  tvAltKategoriAciklama = v.findViewById(R.id.tvAltKategoriAciklama);
        tvAltKategoriAdi.setText(altkategoriler.get(position).getKategoriAdi());
        tvAltKategoriAciklama.setText(altkategoriler.get(position).getKategoriAciklama());
        Glide
                .with(context)
                .load(altkategoriler.get(position).getKategoriResim())
                .into(ivAltKategoriResim);
        return v;
    }
}
