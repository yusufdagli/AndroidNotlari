package com.ysfyazilim.arrayadapter_withobject.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ysfyazilim.arrayadapter_withobject.Model.Ogrenci;
import com.ysfyazilim.arrayadapter_withobject.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        ogrenciler.add(new Ogrenci("Yusuf","Dağlı","Bilgisayar","yusufdagl@gmail.com"));
        ogrenciler.add(new Ogrenci("Yusuf","Dağlı","Bilgisayar","yusufdagl@gmail.com"));
        ogrenciler.add(new Ogrenci("Yusuf","Dağlı","Bilgisayar","yusufdagl@gmail.com"));
        ogrenciler.add(new Ogrenci("Yusuf","Dağlı","Bilgisayar","yusufdagl@gmail.com"));
        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ogrenciler);
        listView.setAdapter(adapter);





    }
}
