package com.ysfyazilim.arrayadapter_withobject.Model;

public class Ogrenci {
    private String ogrenciAdi;
    private String ogrenciSoyadi;
    private String ogrenciBolumu;
    private String ogrenciEmail;

    public Ogrenci() {
    }

    public Ogrenci(String ogrenciAdi, String ogrenciSoyadi, String ogrenciBolumu, String ogrenciEmail) {
        this.ogrenciAdi = ogrenciAdi;
        this.ogrenciSoyadi = ogrenciSoyadi;
        this.ogrenciBolumu = ogrenciBolumu;
        this.ogrenciEmail = ogrenciEmail;
    }

    public String getOgrenciAdi() {
        return ogrenciAdi;
    }

    public void setOgrenciAdi(String ogrenciAdi) {
        this.ogrenciAdi = ogrenciAdi;
    }

    public String getOgrenciSoyadi() {
        return ogrenciSoyadi;
    }

    public void setOgrenciSoyadi(String ogrenciSoyadi) {
        this.ogrenciSoyadi = ogrenciSoyadi;
    }

    public String getOgrenciBolumu() {
        return ogrenciBolumu;
    }

    public void setOgrenciBolumu(String ogrenciBolumu) {
        this.ogrenciBolumu = ogrenciBolumu;
    }

    public String getOgrenciEmail() {
        return ogrenciEmail;
    }

    public void setOgrenciEmail(String ogrenciEmail) {
        this.ogrenciEmail = ogrenciEmail;
    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "ogrenciAdi='" + ogrenciAdi + '\'' +
                ", ogrenciSoyadi='" + ogrenciSoyadi + '\'' +
                ", ogrenciBolumu='" + ogrenciBolumu + '\'' +
                ", ogrenciEmail='" + ogrenciEmail + '\'' +
                '}';
    }
}
