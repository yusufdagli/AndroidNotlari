package com.ysfyazilim.intentornegi2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn1,btn2,btn3,btn4,btn5;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        intent = new Intent(getApplicationContext(),SecondActivity.class);



    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.btn1)
        {
            intent.putExtra("name",btn1);
        }
        else if (v.getId()==R.id.btn2)
        {
            intent.putExtra("name",btn2);
        }
        else if (v.getId()==R.id.btn3)
        {
            intent.putExtra("name",btn1);
        }
        else if (v.getId()==R.id.btn4)
        {

        }
        else if (v.getId()==R.id.btn5)
        {

        }
    }
}
