package ysfyazili.com;


import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginRegisterActivity extends AppCompatActivity {

    EditText etMail,etPassword;
    Button btnGiris,btnKayit;


    private FirebaseAuth mAuth;

    String name,mail,uid;
    Uri photoUrl;
    boolean emailVerified;

    public void kayitOl(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                            if (user != null) {
                                name = user.getDisplayName();
                                mail = user.getEmail();
                                photoUrl = user.getPhotoUrl();
                                emailVerified = user.isEmailVerified();
                                uid = user.getUid();

                                Intent intent = new Intent(getApplicationContext(),LoggedActivity.class);
                                intent.putExtra("name",name);
                                intent.putExtra("mail",mail);
                                intent.putExtra("photoUrl",photoUrl);
                                intent.putExtra("emailVerified",emailVerified);
                                intent.putExtra("uid",uid);
                                startActivity(intent);
                            }



                            //updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(LoginRegisterActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();

                        }


                    }
                });
    }

    public void girisYap(String email,String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("", "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                            if (user != null) {
                                name = user.getDisplayName();
                                mail = user.getEmail();
                                photoUrl = user.getPhotoUrl();
                                emailVerified = user.isEmailVerified();
                                uid = user.getUid();

                                Intent intent = new Intent(getApplicationContext(),LoggedActivity.class);
                                intent.putExtra("name",name);
                                intent.putExtra("mail",mail);
                                intent.putExtra("photoUrl",photoUrl);
                                intent.putExtra("emailVerified",emailVerified);
                                intent.putExtra("uid",uid);
                                startActivity(intent);

                            }



                            //updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("", "signInWithEmail:failure", task.getException());
                            Toast.makeText(LoginRegisterActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }

                        // ...
                    }
                });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        btnGiris = findViewById(R.id.btnGiris);
        btnKayit = findViewById(R.id.btnKayit);
        etMail = findViewById(R.id.etMail);
        etPassword = findViewById(R.id.etPassword);

        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                girisYap(etMail.getText().toString(),etPassword.getText().toString());
            }
        });

        btnKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kayitOl(etMail.getText().toString(),etPassword.getText().toString());
            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        //updateUI(currentUser);
    }
}