package com.ysfyazilim.customspinner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    CustomAdapter adapter;
    int[] bayraklar = {R.drawable.tr,R.drawable.ar,R.drawable.in,R.drawable.tn};
    String[] ulkeler = {"Türkiye Cumhuriyeti","Suudi Arabistan","Hindistan","Tunus"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new CustomAdapter(this,bayraklar,ulkeler);
        spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

    }
}
