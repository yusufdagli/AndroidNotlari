package com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Adapter.ItemAdapter;
import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Model.Uyeler;
import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private ArrayList<Uyeler> uyeList;
    RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uyeList = new ArrayList<>();
        listeyiDoldur(uyeList);

        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        itemAdapter = new ItemAdapter(uyeList);
        mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(itemAdapter);
    }

    private void listeyiDoldur(ArrayList<Uyeler> uyeList){
        uyeList.add(new Uyeler("Şerif GÜNGÖR","contact@serifgungor.com","https://serifgungor.com/images/my-photo.jpg"));
        uyeList.add(new Uyeler("Şerif GÜNGÖR","contact@serifgungor.com","https://serifgungor.com/images/my-photo.jpg"));
        uyeList.add(new Uyeler("Şerif GÜNGÖR","contact@serifgungor.com","https://serifgungor.com/images/my-photo.jpg"));
    }
}