package com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;
import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Holder.ItemHolder;
import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.Model.Uyeler;
import com.ysfyazilim.recyclerviewadaptercardviewkullanimi.R;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

    private List<Uyeler> uyelerList;

    public ItemAdapter(List<Uyeler> uyelerList) {
        this.uyelerList = uyelerList;
    }

    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout, parent, false);

        return new ItemHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ItemHolder holder, int position) {
        Uyeler uye = uyelerList.get(position);
        holder.txtAd.setText(uye.getAd());
        holder.txtEmail.setText(uye.getEmail());
        Picasso.with(holder.txtAd.getContext()).load(uye.getProfilResim()).into(holder.profilResim);
    }

    @Override
    public int getItemCount() {
        return uyelerList.size();
    }
}
