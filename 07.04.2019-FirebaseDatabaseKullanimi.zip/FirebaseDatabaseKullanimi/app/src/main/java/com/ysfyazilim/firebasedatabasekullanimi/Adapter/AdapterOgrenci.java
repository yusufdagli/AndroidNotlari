package com.ysfyazilim.firebasedatabasekullanimi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ysfyazilim.firebasedatabasekullanimi.Model.Ogrenci;
import com.ysfyazilim.firebasedatabasekullanimi.R;

import java.util.ArrayList;


public class AdapterOgrenci extends BaseAdapter {
    private ArrayList<Ogrenci> ogrenciler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterOgrenci() {
    }

    public AdapterOgrenci(ArrayList<Ogrenci> ogrenciler, Context context) {
        this.ogrenciler = ogrenciler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return ogrenciler.size();
    }

    @Override
    public Object getItem(int position) {
        return ogrenciler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.satir_goruntusu,null);
        TextView tvAdSoyad,tvOkul,tvBolum,tvTelefonNo;

        tvAdSoyad = v.findViewById(R.id.tvOgrenciAdSoyad);
        tvOkul = v.findViewById(R.id.tvOkul);
        tvBolum = v.findViewById(R.id.tvBolum);
        tvTelefonNo = v.findViewById(R.id.tvTelefonNo);

        tvAdSoyad.setText(""+ogrenciler.get(position).getAdSoyad());
        tvOkul.setText(""+ogrenciler.get(position).getOkul());
        tvBolum.setText(""+ogrenciler.get(position).getBolum());
        tvTelefonNo.setText(""+ogrenciler.get(position).getTelefonNo());

        return v;
    }
}