package com.ysfyazilim.firebasedatabasekullanimi.Model;

public class Ogrenci {
    private int ogrenciNo;
    private String adSoyad;
    private int telefonNo;
    private int tcNo;
    private String okul;
    private String bolum;
    private int okulaGirisYili;

    public Ogrenci() {
    }

    public Ogrenci(int ogrenciNo, String adSoyad, int telefonNo, int tcNo, String okul, String bolum, int okulaGirisYili) {
        this.ogrenciNo = ogrenciNo;
        this.adSoyad = adSoyad;
        this.telefonNo = telefonNo;
        this.tcNo = tcNo;
        this.okul = okul;
        this.bolum = bolum;
        this.okulaGirisYili = okulaGirisYili;
    }

    public int getOgrenciNo() {
        return ogrenciNo;
    }

    public void setOgrenciNo(int ogrenciNo) {
        this.ogrenciNo = ogrenciNo;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public int getTelefonNo() {
        return telefonNo;
    }

    public void setTelefonNo(int telefonNo) {
        this.telefonNo = telefonNo;
    }

    public int getTcNo() {
        return tcNo;
    }

    public void setTcNo(int tcNo) {
        this.tcNo = tcNo;
    }

    public String getOkul() {
        return okul;
    }

    public void setOkul(String okul) {
        this.okul = okul;
    }

    public String getBolum() {
        return bolum;
    }

    public void setBolum(String bolum) {
        this.bolum = bolum;
    }

    public int getOkulaGirisYili() {
        return okulaGirisYili;
    }

    public void setOkulaGirisYili(int okulaGirisYili) {
        this.okulaGirisYili = okulaGirisYili;
    }
}
