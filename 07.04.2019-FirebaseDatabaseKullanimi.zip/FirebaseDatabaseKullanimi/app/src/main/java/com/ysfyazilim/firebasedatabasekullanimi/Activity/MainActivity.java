package com.ysfyazilim.firebasedatabasekullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ysfyazilim.firebasedatabasekullanimi.Adapter.AdapterOgrenci;
import com.ysfyazilim.firebasedatabasekullanimi.Model.Ogrenci;
import com.ysfyazilim.firebasedatabasekullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    AdapterOgrenci adapterOgrenci;
    ListView listView ;
    FirebaseDatabase database;
    DatabaseReference myRef;

    public void ogrenciEkle(Ogrenci ogrenci)
    {
        //int ogrenciNo, String adSoyad, int telefonNo, int tcNo, String okul, String bolum, int okulaGirisYili
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child("ogrenciler");
        dbRef.push().setValue(
                new Ogrenci(
                        ogrenci.getOgrenciNo(),
                        ogrenci.getAdSoyad(),
                        ogrenci.getTelefonNo(),
                        ogrenci.getTcNo(),
                        ogrenci.getOkul(),
                        ogrenci.getBolum(),
                        ogrenci.getOkulaGirisYili()));

    }

    public ArrayList<Ogrenci> ogrencileriCagir()
    {
        final ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
        myRef.child("ogrenciler").addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(DataSnapshot dataSnapshot) {
                ogrenciler.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Ogrenci ogrenci = snapshot.getValue(Ogrenci.class);
                    ogrenciler.add(
                            new Ogrenci(
                                    ogrenci.getOgrenciNo(),
                                    ogrenci.getAdSoyad(),
                                    ogrenci.getTelefonNo(),
                                    ogrenci.getTcNo(),
                                    ogrenci.getOkul(),
                                    ogrenci.getBolum(),
                                    ogrenci.getOkulaGirisYili()
                            )
                    );
                }
                adapterOgrenci = new AdapterOgrenci(ogrenciler,getApplicationContext());
                listView.setAdapter(adapterOgrenci);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}

        });
        return ogrenciler;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
        Ogrenci ogrenci1 = new Ogrenci();
        ogrenci1.setOgrenciNo(1);
        ogrenci1.setAdSoyad("Yusuf Dağlı");
        ogrenci1.setTelefonNo(1212221212);
        ogrenci1.setTcNo(212121221);
        ogrenci1.setOkul("Kırklareli Üniversitesi");
        ogrenci1.setBolum("Bilgisayar Programcılığı");
        ogrenci1.setOkulaGirisYili(2012);

        ogrenciEkle(ogrenci1);
        ogrenciler = ogrencileriCagir();

        /*FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");
        */
       /* myRef.setValue("Hello, World!");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("FIREBASE", "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("FIREBASE", "Failed to read value.", error.toException());
            }
        }); */


    }


}
