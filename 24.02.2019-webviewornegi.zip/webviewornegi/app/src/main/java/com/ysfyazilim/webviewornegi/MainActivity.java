package com.ysfyazilim.webviewornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btngit;
    WebView webview;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btngit = findViewById(R.id.btngit);
        editText = findViewById(R.id.editText);
        webview = findViewById(R.id.webview);
        btngit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String web = editText.getText().toString();
                webview.loadUrl(web);
                webview.getSettings().setJavaScriptEnabled(true);
                webview.setWebViewClient(new WebViewClient());
            }
        });
    }

}
