package com.ysfyazilim.dialognesnesikullanimi;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnAlert,btncustomAlertDialog,btnRadioGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAlert = findViewById(R.id.btnAlertDialog);
        btncustomAlertDialog = findViewById(R.id.btnCustomAlertDialog);
        btnAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogUret();
            }
        });
        btncustomAlertDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customAlertDialog("baslik","aciklama","evet","","");
            }
        });
        btnRadioGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                radioGroupDialogUret(new String[]{"Mavi","Kırmızı","Yeşil"},"renk",);
            }
        });




    }
    public void alertDialogUret()
    {
        AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
        adb.setTitle("Dialog Başlığı");
        adb.setMessage("Bu bir içerik yazısıdır");
        adb.setNegativeButton("Hayır", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        adb.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        adb.setNeutralButton("Vazgec",null);
        adb.create();
        adb.show();
    }
    public  void customAlertDialog(@NonNull String baslik,
                                   @NonNull String aciklama,
                                   @Nullable String olumluButonBaslik,
                                   @Nullable String olumsuzButonBaslik,
                                   @Nullable String kararsizbutonbaslik
                                    ){
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.custom_alertdialog);
        TextView tvBaslik = dialog.findViewById(R.id.tvBaslik);
        TextView tvAciklama = dialog.findViewById(R.id.tvAciklama);
        Button btnOlumlu,btnOlumsuz,btnKararsiz;
        btnOlumlu = dialog.findViewById(R.id.btnEvet);
        btnOlumsuz = dialog.findViewById(R.id.btnHayir);
        btnKararsiz = dialog.findViewById(R.id.btnVazgec);
        tvBaslik.setText(baslik);
        tvAciklama.setText(aciklama);
        dialog.setCancelable(false); //dialog dışına basılınca kapanmasın

        if(olumluButonBaslik.isEmpty())
        {
            btnOlumlu.setVisibility(View.GONE);

        }
        else
        {
            btnOlumlu.setText(olumluButonBaslik);
            btnOlumlu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
        if(olumsuzButonBaslik.isEmpty())
        {
            btnOlumsuz.setVisibility(View.GONE);
        }
        else
        {
            btnOlumsuz.setText(olumsuzButonBaslik);
            btnOlumsuz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
        if(kararsizbutonbaslik.isEmpty())
        {
            btnKararsiz.setVisibility(View.GONE);
        }
        else
        {
            btnKararsiz.setText(kararsizbutonbaslik);
            btnKararsiz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }

        dialog.show();

    };
    public  void radioGroupDialogUret(String[] elemanlar,String baslik)
    {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.customdialog_radiogroup);
        TextView tvBaslik = dialog.findViewById(R.id.tvRadioBaslik);
        RadioGroup radioGroup = dialog.findViewById(R.id.radioGroup);
        for (int i=0;i<elemanlar.length;i++)
        {
            RadioButton btn = new RadioButton(getApplicationContext());
            btn.setText(elemanlar[i]);
            radioGroup.addView(btn);
        }
        tvBaslik.setText(baslik);
        Button btnKapat = dialog.findViewById(R.id.btnRadioKapat);
        btnKapat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();



    }

}
