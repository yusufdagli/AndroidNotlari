package com.ysfyazilim.intentkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView tvNameSurname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tvNameSurname = findViewById(R.id.tvNameSurname);
        String namesurname = getIntent().getStringExtra("namesurname");
        tvNameSurname.setText(namesurname);


    }
}
