package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterUrun;
import com.serifgungor.satisuygulamasi.Helper.DatabaseHelper;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class UrunlerActivity extends AppCompatActivity {

    ArrayList<Urun> urunler = new ArrayList<>();
    AdapterUrun adapterUrun;
    GridView gridView;
    DatabaseHelper databaseHelper;
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunler);

        AltKategori altKategori = (AltKategori)getIntent().getSerializableExtra("altKategori");

        this.setTitle(altKategori.getKategoriAdi() + " Ürünleri");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        gridView = findViewById(R.id.gridViewUrunler);




        try{
            databaseHelper = new DatabaseHelper(getApplicationContext());
            databaseHelper.createDatabase();
            db = databaseHelper.getReadableDatabase();
            c = db.rawQuery("Select * from Urun where altKategoriId ="+altKategori.getId()  ,null);
            while(c.moveToNext()){


                urunler.add(new Urun(c.getInt(c.getColumnIndex("id")),c.getInt(c.getColumnIndex("altKategoriId")),c.getString(c.getColumnIndex("baslik")),c.getInt(c.getColumnIndex("fiyat")),c.getString(c.getColumnIndex("resim")),c.getString(c.getColumnIndex("aciklama"))));
            }

        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }



        adapterUrun = new AdapterUrun(urunler,getApplicationContext());
        gridView.setAdapter(adapterUrun);


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(),UrunDetayActivity.class);
                intent.putExtra("urun",urunler.get(position));
                startActivity(intent);

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
