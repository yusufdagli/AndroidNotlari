package com.serifgungor.satisuygulamasi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

public class UrunDetayActivity extends AppCompatActivity {

    TextView tvBaslik,tvFiyat,tvAciklama;
    ImageView ivResim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urun_detay);

        Urun urun = (Urun)getIntent().getSerializableExtra("urun");

        this.setTitle(urun.getBaslik());

        ivResim = findViewById(R.id.ivUrunDetay);
        tvBaslik = findViewById(R.id.tvUrunDetayBaslik);
        tvFiyat = findViewById(R.id.tvUrunDetayFiyat);
        tvAciklama = findViewById(R.id.tvUrunDetayAciklama);


        Glide
                .with(getApplicationContext())
                .load(urun.getResim())
                .into(ivResim);

        tvFiyat.setText(""+urun.getFiyat());
        tvAciklama.setText(urun.getAciklama());


    }
}
