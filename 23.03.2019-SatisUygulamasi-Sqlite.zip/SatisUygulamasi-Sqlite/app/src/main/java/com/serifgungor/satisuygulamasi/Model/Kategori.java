package com.serifgungor.satisuygulamasi.Model;

import java.io.Serializable;

public class Kategori implements Serializable {
    private int id;
    private String ad;
    private String resim;

    public Kategori() {
    }

    public Kategori(int id, String ad, String resim) {
        this.id = id;
        this.ad = ad;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }
}
