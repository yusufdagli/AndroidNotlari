package com.ysfyazilim.hesapmakinesi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etsayi1,etsayi2;
    Button btntopla,btncikar,btnbol,btncarp;
    TextView tvsonuc;
    int sayi1,sayi2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etsayi1 = findViewById(R.id.etsayi1);
        etsayi2 = findViewById(R.id.etsayi2);
        btntopla = findViewById(R.id.btntopla);
        btncikar = findViewById(R.id.btncikar);
        btnbol = findViewById(R.id.btnbol);
        btncarp = findViewById(R.id.btncarp);
        tvsonuc = findViewById(R.id.tvsonuc);


        btntopla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sayi1 = Integer.parseInt(etsayi1.getText().toString());
                int sayi2 = Integer.parseInt(etsayi2.getText().toString());
                tvsonuc.setText(""+(sayi1+sayi2));




            }
        });
        btncikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sayi1 = Integer.parseInt(etsayi1.getText().toString());
                int sayi2 = Integer.parseInt(etsayi2.getText().toString());
                tvsonuc.setText(""+(sayi1-sayi2));
            }
        });
        btncarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sayi1 = Integer.parseInt(etsayi1.getText().toString());
                int sayi2 = Integer.parseInt(etsayi2.getText().toString());
                tvsonuc.setText(""+(sayi1*sayi2));
            }
        });
        btnbol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sayi1 = Integer.parseInt(etsayi1.getText().toString());
                int sayi2 = Integer.parseInt(etsayi2.getText().toString());
                tvsonuc.setText(""+(sayi1/sayi2));

            }
        });
    }

}
