package com.ysfyazilim.baseadapter_withtakimlar.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.ListView;

import com.ysfyazilim.baseadapter_withtakimlar.Adapter.AdapterOyuncu;
import com.ysfyazilim.baseadapter_withtakimlar.Model.Oyuncu;
import com.ysfyazilim.baseadapter_withtakimlar.R;

import java.util.ArrayList;

public class OyuncularActivity extends AppCompatActivity {
    ListView listView;
    AdapterOyuncu adapterOyuncu;
    ArrayList<Oyuncu> oyuncular = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuncular);
        String takim = getIntent().getStringExtra("takim_adi");
        setTitle(takim);
        //toolbar'a geri butonu ekler
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = findViewById(R.id.listViewOyuncular);
        if ("Galatasaray".equals(takim))
        {
           oyuncular.add(new Oyuncu(1,"Fernando Muslera","fernandomuslera",33,1));
           oyuncular.add(new Oyuncu(2,"Semih Kaya","semihkaya",27,26));
        }
        else if("Fenerbahçe".equals(takim))
        {
            oyuncular.add(new Oyuncu(1,"Harun Tekin","haruntekin",29,35));
            oyuncular.add(new Oyuncu(2,"Volkan Demirel","volkandemirel",33,1));

        }
        adapterOyuncu = new AdapterOyuncu(oyuncular,getApplicationContext());
        listView.setAdapter(adapterOyuncu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
