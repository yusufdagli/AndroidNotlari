package com.ysfyazilim.baseadapter_withtakimlar.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.ysfyazilim.baseadapter_withtakimlar.Adapter.AdapterTakim;
import com.ysfyazilim.baseadapter_withtakimlar.Model.Takimlar;
import com.ysfyazilim.baseadapter_withtakimlar.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Takimlar> takimlar = new ArrayList<>();
    AdapterTakim adapterTakim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        takimlar.add(new Takimlar("Fenerbahçe",R.drawable.fenerbahce));
        takimlar.add(new Takimlar("Galatasaray",R.drawable.galatasaray));
        takimlar.add(new Takimlar("Beşiktaş",R.drawable.besiktas));
        takimlar.add(new Takimlar("Trabzonspor",R.drawable.trabzonspor));
        adapterTakim = new AdapterTakim(takimlar,getApplicationContext());
        listView.setAdapter((ListAdapter) adapterTakim);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(new Intent(
                        getApplicationContext(),OyuncularActivity.class)
                        .putExtra("takim_adi",takimlar.get(position).getTakimadi())
                );
            }
        });
    }
}
