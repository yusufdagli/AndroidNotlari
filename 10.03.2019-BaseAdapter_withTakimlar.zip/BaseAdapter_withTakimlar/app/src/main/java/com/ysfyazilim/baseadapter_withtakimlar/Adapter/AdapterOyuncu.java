package com.ysfyazilim.baseadapter_withtakimlar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ysfyazilim.baseadapter_withtakimlar.Model.Oyuncu;
import com.ysfyazilim.baseadapter_withtakimlar.R;

import java.util.ArrayList;

public class AdapterOyuncu extends BaseAdapter {

    private ArrayList<Oyuncu> oyuncular ;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterOyuncu() {
    }

    public AdapterOyuncu(ArrayList<Oyuncu> oyuncular, Context context) {
        this.oyuncular = oyuncular;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return oyuncular.size();
    }

    @Override
    public Object getItem(int position) {
        return oyuncular.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.oyuncu_satirgoruntusu,null);
        TextView tvOyuncuAdSoyad,tvOyuncuYas,tvOyuncuFormaNo;
        ImageView ivOyuncu = v.findViewById(R.id.ivOyuncu);
        tvOyuncuAdSoyad = v.findViewById(R.id.tvOyuncuAdSoyad);
        tvOyuncuYas = v.findViewById(R.id.tvOyuncuYas);
        tvOyuncuFormaNo  = v.findViewById(R.id.tvOyuncuFormaNo);
        tvOyuncuAdSoyad.setText(oyuncular.get(position).getAdSoyad());
        tvOyuncuFormaNo.setText(""+oyuncular.get(position).getFormaNo());
        tvOyuncuYas.setText(""+oyuncular.get(position).getYas());
        int resim = v.getResources().getIdentifier(
                oyuncular.get(position).getResim(),
                "drawable",
                context.getPackageName()

        );
        ivOyuncu.setImageResource(resim);
        return v ;
    }
}
