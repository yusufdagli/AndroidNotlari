package com.ysfyazilim.baseadapter_withtakimlar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ysfyazilim.baseadapter_withtakimlar.Model.Takimlar;
import com.ysfyazilim.baseadapter_withtakimlar.R;


import java.util.ArrayList;

public class AdapterTakim extends BaseAdapter {
  private ArrayList<Takimlar> takimlar;
  private Context context;
  private LayoutInflater layoutInflater;

    public AdapterTakim() {
    }

    public AdapterTakim(ArrayList<Takimlar> takimlar, Context context) {
        this.takimlar = takimlar;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    };

    @Override
    public int getCount() {
        //listenin eleman sayısı
        return takimlar.size();
    }

    @Override
    public Takimlar getItem(int position) {
        //listenin i'nin sıradaki elemanını döner
        return takimlar.get(position) ;
    }

    @Override
    public long getItemId(int position) {
        //Listedeki elemanın kaçıncı sırada olduğunu döner
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Liste elemanının satır görüntüsünü döner
        // index = position
        View v = layoutInflater.inflate(R.layout.takim_satirgoruntusu,null);
        ImageView ivResim = v.findViewById(R.id.ivResim);
        TextView tvBaslik = v.findViewById(R.id.tvBaslik);
        tvBaslik.setText(takimlar.get(position).getTakimadi());
        ivResim.setImageResource(takimlar.get(position).getTakimLogo());
        return v  ;
    }





}
