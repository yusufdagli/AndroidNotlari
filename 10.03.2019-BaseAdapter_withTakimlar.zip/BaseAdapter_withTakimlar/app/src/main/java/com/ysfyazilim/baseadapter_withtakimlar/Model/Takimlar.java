package com.ysfyazilim.baseadapter_withtakimlar.Model;

public class Takimlar {
    private String takimadi;
    private int takimLogo;

    public Takimlar() {
    }

    public Takimlar(String takimadi, int takimLogo) {
        this.takimadi = takimadi;
        this.takimLogo = takimLogo;
    }

    public String getTakimadi() {
        return takimadi;
    }

    public void setTakimadi(String takimadi) {
        this.takimadi = takimadi;
    }

    public int getTakimLogo() {
        return takimLogo;
    }

    public void setTakimLogo(int takimLogo) {
        this.takimLogo = takimLogo;
    }
}
