package com.ysfyazilim.customlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<PhoneModel> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayList.add(
                new PhoneModel(1,"Şerif","0212 000 11 22","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Ben","0212 000 11 33","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Sen","0212 000 11 44","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"O","0212 000 11 55","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Biz","0212 000 11 66","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Siz","0212 000 11 77","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );
        arrayList.add(
                new PhoneModel(1,"Onlar","0212 000 11 88","https://serifgungor.com/content/uploads/images/0119/android-http-url-connection-bitmap-kullanimi-2.jpg")
        );

        listView = (ListView)findViewById(R.id.listView);
        ListViewAdapter adapter = new ListViewAdapter(getApplicationContext(),arrayList);
        listView.setAdapter(adapter);
    }
    }

