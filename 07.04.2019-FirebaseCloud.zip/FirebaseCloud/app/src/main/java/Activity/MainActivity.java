package Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.messaging.FirebaseMessaging;

import ysfyazilim.com.BuildConfig;
import ysfyazilim.com.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (BuildConfig.DEBUG)
        {
            FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        }
        else
        {
            FirebaseMessaging.getInstance().setAutoInitEnabled(false);
        }

    }
}



