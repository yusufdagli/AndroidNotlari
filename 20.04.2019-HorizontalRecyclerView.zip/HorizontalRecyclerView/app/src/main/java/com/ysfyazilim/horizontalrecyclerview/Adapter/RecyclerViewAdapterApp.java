package com.ysfyazilim.horizontalrecyclerview.Adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.ysfyazilim.horizontalrecyclerview.Activity.MainActivity;
import com.ysfyazilim.horizontalrecyclerview.Holder.ViewHolderApp;
import com.ysfyazilim.horizontalrecyclerview.Model.App;
import com.ysfyazilim.horizontalrecyclerview.R;

import java.util.List;

public class RecyclerViewAdapterApp extends RecyclerView.Adapter<ViewHolderApp> {

    private List<App> appList;

    public RecyclerViewAdapterApp(){}

    public RecyclerViewAdapterApp(List<App> apps){
        this.appList = apps;
    }

    @NonNull
    @Override
    public ViewHolderApp onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.app_view,null);
        return new ViewHolderApp(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderApp holder, final int position) {
        holder.tvTitle.setText(appList.get(position).getName());
        holder.tvDeveloper.setText(appList.get(position).getDeveloper());
        holder.tvPoint.setText(""+appList.get(position).getPoint());
        Glide
                .with(holder.itemView.getContext())
                .load(appList.get(position).getPhotourl())
                .into(holder.ivLogo);

        //RecyclerView satıra tıklama olayı
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                intent.putExtra("appid",appList.get(position).getId());
                v.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return appList.size();
    }
}
