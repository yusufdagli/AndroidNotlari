package com.ysfyazilim.bundle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity {
    EditText etAdSoyadSecond,etUniversiteSecond,etSinifSecond;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        etAdSoyadSecond = findViewById(R.id.etAdSoyadSecond);
        etUniversiteSecond = findViewById(R.id.etUniversiteSecond);
        etSinifSecond = findViewById(R.id.etSinifSecond);
        Bundle bundle = new Bundle();
        String adsoyad = bundle.getString("adsoyad");
        String universite = bundle.getString("universite");
        int sinif = bundle.getInt("sinif");
        etAdSoyadSecond.setText(adsoyad);
        etUniversiteSecond.setText(universite);
        etSinifSecond.setText(""+sinif);

    }
}
