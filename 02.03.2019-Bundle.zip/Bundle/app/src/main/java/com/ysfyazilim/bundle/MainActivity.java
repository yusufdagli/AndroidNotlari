package com.ysfyazilim.bundle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText etAdSoyad,etUniversite,etSinif;
    Button btnGonder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etAdSoyad = findViewById(R.id.etAdSoyad);
        etUniversite = findViewById(R.id.etUniversite);
        etSinif = findViewById(R.id.etSinif);
        btnGonder = findViewById(R.id.btnGonder);
        btnGonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v  ) {
                Bundle bundle = new Bundle();
                bundle.putString("adsoyad",etAdSoyad.getText().toString());
                bundle.putString("universite",etUniversite.getText().toString());
                bundle.putInt("sinif",Integer.parseInt(etSinif.getText().toString()));
                Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                 // intent.putExtra("bundle",bundle);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
